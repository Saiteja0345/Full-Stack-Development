// export const BASE_URL = "https://online-voting-system-server.onrender.com";
export const BASE_URL = "https://onlineserver-4uuo.onrender.com"
// export const BASE_URL = "http://localhost:5000"